#install.packages("rms")
#install.packages("rmda")

# Load required libraries
library(rms)     # For regression modeling and nomogram plotting
library(rmda)    # For decision curve analysis

inputFile = "normalize.txt"             # File containing normalized expression data
geneFile = "importanceGene.RF.txt"     # File containing top important genes
setwd("D:\\bioinfor\\sepsis\\sepsis_exosome\\23.Nomo\\GSE66099")  # Set working directory

# Read expression data
data = read.table(inputFile, header = TRUE, sep = "\t", check.names = FALSE, row.names = 1)
row.names(data) = gsub("-", "_", row.names(data))  # Replace '-' with '_'

# Read top important genes and subset expression data
geneRT = read.table(geneFile, header = TRUE, sep = "\t", check.names = FALSE)
data = data[as.vector(geneRT[,1]), ]

# Prepare phenotype information
data = t(data)
group = gsub("(.*)\\_(.*)", "\\2", row.names(data))  # Extract group labels
rt = cbind(as.data.frame(data), Type = group)

# Prepare data distribution object for rms functions
ddist = datadist(rt)
options(datadist = "ddist")

# Fit logistic regression model for selected top genes and generate nomogram
lrmModel = lrm(Type ~ TLR5 + IRAK3 + MCEMP1 + GYG1 + CD177, data = rt, x = TRUE, y = TRUE)
nomo = nomogram(lrmModel, fun = plogis,
                fun.at = c(0.0001, 0.1, 0.3, 0.5, 0.7, 0.9, 0.99),
                lp = FALSE, funlabel = "Risk of Disease")

# Plot nomogram
pdf("Nomo.pdf", width = 12, height = 10)
plot(nomo)
dev.off()

# Calibration of the logistic regression model
cali = calibrate(lrmModel, method = "boot", B = 1000)  # Bootstrap method with 1000 resamples
pdf("Calibration.pdf", width = 5.5, height = 5.5)
plot(cali,
     xlab = "Predicted probability",
     ylab = "Actual probability", sub = FALSE)
dev.off()

# Convert Type to numeric for decision curve analysis (0 = Control, 1 = Disease)
rt$Type = ifelse(rt$Type == "Control", 0, 1)

# Perform decision curve analysis (DCA)
dc = decision_curve(Type ~ TLR5 + IRAK3 + MCEMP1 + GYG1 + CD177, data = rt, 
                    family = binomial(link = 'logit'),
                    thresholds = seq(0, 1, by = 0.01),
                    confidence.intervals = 0.95)

# Plot decision curve
pdf(file = "DCA.pdf", width = 5.5, height = 5.5)
plot_decision_curve(dc,
                    curve.names = "Model",
                    xlab = "Threshold probability",
                    cost.benefit.axis = TRUE,
                    col = "red",
                    confidence.intervals = FALSE,
                    standardize = FALSE)
dev.off()