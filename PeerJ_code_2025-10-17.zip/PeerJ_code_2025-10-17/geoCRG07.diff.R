#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")

#install.packages("pheatmap")
#install.packages("reshape2")
#install.packages("ggpubr")

# Load required packages
library(limma)
library(pheatmap)
library(reshape2)
library(ggpubr)

expFile = "exoGeneExp.txt"      # Expression data file
setwd("D:\\bioinfor\\sepsis\\sepsis_exosome\\07.diff\\GSE66099")      # Set working directory

# Read the expression data file
rt = read.table(expFile, header = TRUE, sep = "\t", check.names = FALSE)
rt = as.matrix(rt)
rownames(rt) = rt[,1]
exp = rt[,2:ncol(rt)]
dimnames = list(rownames(exp), colnames(exp))
data = matrix(as.numeric(as.matrix(exp)), nrow = nrow(exp), dimnames = dimnames)
data = avereps(data)        # Average expression values for duplicated genes
exp = data

# Extract sample grouping information
Type = gsub("(.*)\\_(.*)", "\\2", colnames(data))

# Perform differential expression analysis using the Wilcoxon test
sigVec = c()
sigGeneVec = c()

for(i in row.names(data)){
  test = wilcox.test(data[i,] ~ Type)
  pvalue = test$p.value
  Sig = ifelse(pvalue < 0.001, "***",
               ifelse(pvalue < 0.01, "**",
                      ifelse(pvalue < 0.05, "*", "")))
  if(pvalue < 0.05){
    sigVec = c(sigVec, paste0(i, Sig))
    sigGeneVec = c(sigGeneVec, i)
  }
}

# Output the expression matrix of significantly differentially expressed genes
data = data[sigGeneVec,]
outTab = rbind(ID = colnames(data), data)
write.table(outTab, file = "diffGeneExp.txt", sep = "\t", quote = FALSE, col.names = FALSE)
row.names(data) = sigVec

# Visualize differentially expressed genes using a heatmap
names(Type) = colnames(data)
Type = as.data.frame(Type)
pdf(file = "heatmap5.pdf", width = 7, height = 4.5)
pheatmap(data,
         annotation = Type,
         color = colorRampPalette(c(rep("#FDC917",2), "white", rep("#064E9B",2)))(100),
         cluster_cols = FALSE,
         cluster_rows = TRUE,
         scale = "row",
         show_colnames = FALSE,
         show_rownames = TRUE,
         fontsize = 7,
         fontsize_row = 7,
         fontsize_col = 7)
dev.off()

# Convert expression data into a ggplot2-compatible format
exp = as.data.frame(t(exp))
exp = cbind(exp, Type = Type)
data = melt(exp, id.vars = c("Type"))
colnames(data) = c("Type", "Gene", "Expression")

# Generate boxplots for each gene
p = ggboxplot(data, x = "Gene", y = "Expression", color = "Type", 
              xlab = "",
              ylab = "Gene expression",
              legend.title = "Type",
              palette = c("#FDC917", "#064E9B"),
              add = "point",
              width = 0.8)
p = p + rotate_x_text(45)
p1 = p + stat_compare_means(aes(group = Type),
                            method = "wilcox.test",
                            symnum.args = list(cutpoints = c(0, 0.001, 0.01, 0.05, 1),
                                               symbols = c("***", "**", "*", " ")),
                            label = "p.signif")

# Save boxplot as PDF
pdf(file = "boxplot5.pdf", width = 30, height = 10)
print(p1)
dev.off()
