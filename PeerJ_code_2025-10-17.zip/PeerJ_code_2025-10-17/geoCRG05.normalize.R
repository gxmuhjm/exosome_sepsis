# =========================================================
# Gene Expression Normalization Using the limma Package
# =========================================================

# Install limma if not already installed
#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")

# =========================================================
# Load required package
# =========================================================
library(limma)

# Define file paths
expFile = "geneMatrix.txt"      # expression matrix file
conFile = "s1.txt"              # control group sample list
treatFile = "s2.txt"            # treatment group sample list
setwd("F://WHW//Test_AZ_2022.12.8//05.normalize")   # set working directory

# =========================================================
# Read expression data and preprocess
# =========================================================
rt = read.table(expFile, header = TRUE, sep = "\t", check.names = FALSE)
rt = as.matrix(rt)
rownames(rt) = rt[, 1]
exp = rt[, 2:ncol(rt)]
dimnames = list(rownames(exp), colnames(exp))
data = matrix(as.numeric(as.matrix(exp)), nrow = nrow(exp), dimnames = dimnames)

# Average duplicated gene names
data = avereps(data)    # average expression values for duplicated gene symbols

# =========================================================
# Read control group information and extract expression data
# =========================================================
s1 = read.table(conFile, header = FALSE, sep = "\t", check.names = FALSE)
sampleName1 = as.vector(s1[, 1])
conData = data[, sampleName1]

# =========================================================
# Read treatment group information and extract expression data
# =========================================================
s2 = read.table(treatFile, header = FALSE, sep = "\t", check.names = FALSE)
sampleName2 = as.vector(s2[, 1])
treatData = data[, sampleName2]

# =========================================================
# Merge expression data of both groups
# =========================================================
rt = cbind(conData, treatData)

# =========================================================
# Automatically perform log2 transformation if data not log-transformed
# =========================================================
qx = as.numeric(quantile(rt, c(0, 0.25, 0.5, 0.75, 0.99, 1.0), na.rm = TRUE))
LogC = ((qx[5] > 100) || ((qx[6] - qx[1]) > 50 && qx[2] > 0))
if (LogC) {
  rt[rt < 0] = 0
  rt = log2(rt + 1)
}

# =========================================================
# Boxplot before normalization (to visualize expression distribution)
# =========================================================
boxplot(rt, outline = FALSE, notch = TRUE, las = 2)

# =========================================================
# Normalize expression data using limma
# =========================================================
data = normalizeBetweenArrays(rt)

# =========================================================
# Boxplot after normalization (to compare distribution changes)
# =========================================================
boxplot(rt, outline = FALSE, notch = TRUE, las = 2)

# Reference:
# https://mp.weixin.qq.com/s/CnOwDmB2PP7L6bDWoRM8_g
# "Bioinformatics Beginner��s Weekly Note (12): R Language Study 5 �C Log Transformation"

# =========================================================
# Output normalized expression matrix
# Add group labels (Control/Treat) to sample names
# =========================================================
conNum = ncol(conData)
treatNum = ncol(treatData)
Type = c(rep("Control", conNum), rep("Treat", treatNum))
outData = rbind(id = paste0(colnames(data), "_", Type), data)

write.table(outData, file = "normalize.txt", sep = "\t", quote = FALSE, col.names = FALSE)
