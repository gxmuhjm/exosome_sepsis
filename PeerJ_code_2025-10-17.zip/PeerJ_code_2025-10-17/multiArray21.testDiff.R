###### Video source: https://ke.biowolf.cn
###### BioWolf learning: https://www.biowolf.cn/
###### WeChat public account: biowolf_cn
###### Email: biowolf@foxmail.com
###### WeChat contact: 18520221056

# Install required packages if needed
#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")

#install.packages("ggpubr")
#install.packages("pheatmap")

# Load required libraries
library(limma)     # Differential expression analysis
library(ggpubr)    # Violin plots with statistical comparisons
library(pheatmap)  # Heatmap visualization

# Input files
expFile = "normalize.txt"    # Expression matrix file
geneFile = "hubGenes.csv"    # List of hub genes
cliFile = "clinical.txt"     # Clinical information file

# Set working directory
setwd("D:\\bioinfor\\sepsis\\sepsis_exosome\\26.testdiff\\GSE13904")

# Read expression matrix
rt = read.table(expFile, header = TRUE, sep = "\t", check.names = FALSE)
rt = as.matrix(rt)
rownames(rt) = rt[,1]
exp = rt[,2:ncol(rt)]
dimnames = list(rownames(exp), colnames(exp))
data = matrix(as.numeric(as.matrix(exp)), nrow = nrow(exp), dimnames = dimnames)
data = avereps(data)  # Average replicate probes
colnames(data) = gsub("(.*)\\_(.*)", "\\1", colnames(data))

# Read hub gene list and filter expression matrix
geneRT = read.csv(geneFile, header = TRUE, sep = ",", check.names = FALSE)
sameGene = intersect(as.vector(geneRT[,1]), row.names(data))
data = data[sameGene,,drop = FALSE]
data = t(data)

# Read clinical information and align samples
clinical = read.table(cliFile, header = TRUE, sep = "\t", check.names = FALSE, row.names = 1)
colnames(clinical) = c("Type")
clinical[,"Type"] = factor(clinical[,"Type"], levels = unique(clinical[,"Type"]))
sameSample = intersect(row.names(clinical), row.names(data))
data = cbind(data[sameSample,,drop = FALSE], clinical[sameSample,,drop = FALSE])

# Define pairwise comparisons
group = levels(factor(data[,"Type"]))
comp = combn(group, 2)
my_comparisons = list()
for(i in 1:ncol(comp)) { my_comparisons[[i]] <- comp[,i] }

# Generate violin plots for each hub gene with statistical comparisons
for(i in colnames(data)[1:(ncol(data)-1)]){
  rt1 = data[, c(i, "Type")]
  
  # Violin plot with overlaid boxplot and p-value significance
  boxplot = ggviolin(rt1, x = "Type", y = i, fill = "Type",
                     xlab = "",
                     ylab = paste0(i, " expression"),
                     legend.title = "",
                     palette = c("#DF8F44","#374E55","#008B45FF"),
                     width = 1, add = "boxplot", add.params = list(fill = "white")) + 
    stat_compare_means(comparisons = my_comparisons,
                       symnum.args = list(cutpoints = c(0, 0.001, 0.01, 0.05, 1),
                                          symbols = c("***", "**", "*", "ns")),
                       label = "p.signif")
  
  # Save plot as PDF
  pdf(file = paste0("violin.", i, ".pdf"), width = 5.5, height = 4.5)
  print(boxplot)
  dev.off()
}

# Generate heatmap for hub genes
Type = data[, ncol(data), drop = FALSE]
hmExp = t(data[, -ncol(data), drop = FALSE])
pdf(file = "test.heatmap.pdf", width = 7.5, height = 3.5)
pheatmap(hmExp, 
         annotation = Type, 
         color = colorRampPalette(c(rep("#374E55", 2), "white", rep("#DF8F44", 2)))(50),
         cluster_cols = FALSE,
         show_colnames = FALSE,
         scale = "row",
         fontsize = 8,
         fontsize_row = 7,
         fontsize_col = 8)
dev.off()

###### Video source: https://ke.biowolf.cn
###### BioWolf learning: https://www.biowolf.cn/
###### WeChat public account: biowolf_cn
###### Email: biowolf@foxmail.com
###### WeChat contact: 18520221056