#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install(c("GO.db", "preprocessCore", "impute","limma"))

#install.packages(c("gplots", "matrixStats", "Hmisc", "foreach", "doParallel", "fastcluster", "dynamicTreeCut", "survival")) 
#install.packages("WGCNA")

# Load required packages
library(limma)
library(gplots)
library(WGCNA)

expFile = "normalize.txt"      # File containing normalized gene expression
setwd("F://WHW//Test_AZ_2022.12.31.6th//19.WGCNA")  # Set working directory

# Read gene expression file and convert to matrix
rt = read.table(expFile, header = TRUE, sep = "\t", check.names = FALSE)
rt = as.matrix(rt)
rownames(rt) = rt[,1]
exp = rt[,2:ncol(rt)]
dimnames = list(rownames(exp), colnames(exp))
data = matrix(as.numeric(as.matrix(exp)), nrow = nrow(exp), dimnames = dimnames)
data = avereps(data)   # Average replicate gene expression

# Select top 25% of genes by variance for WGCNA
selectGenes = names(tail(sort(apply(data, 1, sd)), n = round(nrow(data) * 0.25)))
data = data[selectGenes, ]

# Extract sample group information (Control vs Treat)
Type = gsub("(.*)\\_(.*)", "\\2", colnames(data))
conCount = length(Type[Type == "Control"])
treatCount = length(Type[Type == "Treat"])
datExpr0 = t(data)  # Transpose for WGCNA (samples as rows)

# Check for good samples and genes
gsg = goodSamplesGenes(datExpr0, verbose = 3)
if (!gsg$allOK){
  if (sum(!gsg$goodGenes) > 0)
    printFlush(paste("Removing genes:", paste(names(datExpr0)[!gsg$goodGenes], collapse = ", ")))
  if (sum(!gsg$goodSamples) > 0)
    printFlush(paste("Removing samples:", paste(rownames(datExpr0)[!gsg$goodSamples], collapse = ", ")))
  datExpr0 = datExpr0[gsg$goodSamples, gsg$goodGenes]
}

# Sample clustering to detect outliers
sampleTree = hclust(dist(datExpr0), method = "average")
pdf(file = "01.sample_cluster.pdf", width = 12, height = 9)
par(cex = 0.6)
par(mar = c(0,4,2,0))
plot(sampleTree, main = "Sample clustering to detect outliers", sub="", xlab="", cex.lab = 1.5, cex.axis = 1.5, cex.main = 2)
abline(h = 20000, col = "red")  # Cutoff line for outlier removal
dev.off()

# Remove outlier samples
clust = cutreeStatic(sampleTree, cutHeight = 20000, minSize = 10)
table(clust)
keepSamples = (clust == 1)
datExpr0 = datExpr0[keepSamples, ]

# Prepare trait data
traitData = data.frame(Con = c(rep(1, conCount), rep(0, treatCount)),
                       Treat = c(rep(0, conCount), rep(1, treatCount)))
rownames(traitData) = colnames(data)
fpkmSamples = rownames(datExpr0)
traitSamples = rownames(traitData)
sameSample = intersect(fpkmSamples, traitSamples)
datExpr0 = datExpr0[sameSample, ]
datTraits = traitData[sameSample, ]

# Sample dendrogram and trait heatmap
sampleTree2 = hclust(dist(datExpr0), method = "average")
traitColors = numbers2colors(datTraits, signed = FALSE)
pdf(file = "02.sample_heatmap.pdf", width = 12, height = 12)
plotDendroAndColors(sampleTree2, traitColors,
                    groupLabels = names(datTraits),
                    main = "Sample dendrogram and trait heatmap")
dev.off()

# Pick soft-thresholding power
enableWGCNAThreads()  # Enable multi-threading
powers = c(1:20)      # Candidate powers
sft = pickSoftThreshold(datExpr0, powerVector = powers, verbose = 5)

# Scale-free topology and mean connectivity plots
pdf(file = "03.scale_independence.pdf", width = 9, height = 5)
par(mfrow = c(1,2))
cex1 = 0.9
plot(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
     xlab="Soft Threshold (power)", ylab="Scale Free Topology Model Fit,signed R^2", type="n",
     main = "Scale independence")
text(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
     labels = powers, cex = cex1, col = "red")
abline(h = 0.90, col = "red")  # Target R^2 for scale-free topology
plot(sft$fitIndices[,1], sft$fitIndices[,5],
     xlab = "Soft Threshold (power)", ylab = "Mean Connectivity", type = "n",
     main = "Mean connectivity")
text(sft$fitIndices[,1], sft$fitIndices[,5], labels = powers, cex = cex1, col = "red")
dev.off()

# Compute adjacency and TOM
softPower = sft$powerEstimate
adjacency = adjacency(datExpr0, power = softPower)
TOM = TOMsimilarity(adjacency)
dissTOM = 1 - TOM

# Hierarchical clustering of genes based on TOM
geneTree = hclust(as.dist(dissTOM), method = "average")
pdf(file = "04.gene_clustering.pdf", width = 12, height = 9)
plot(geneTree, xlab = "", sub = "", main = "Gene clustering on TOM-based dissimilarity", labels = FALSE, hang = 0.04)
dev.off()

# Dynamic tree cut to identify modules
minModuleSize = 100
dynamicMods = cutreeDynamic(dendro = geneTree, distM = dissTOM,
                            deepSplit = 2, pamRespectsDendro = FALSE,
                            minClusterSize = minModuleSize)
dynamicColors = labels2colors(dynamicMods)
pdf(file = "05.Dynamic_Tree.pdf", width = 8, height = 6)
plotDendroAndColors(geneTree, dynamicColors, "Dynamic Tree Cut",
                    dendroLabels = FALSE, hang = 0.03,
                    addGuide = TRUE, guideHang = 0.05,
                    main = "Gene dendrogram and module colors")
dev.off()

# Module eigengenes clustering
MEList = moduleEigengenes(datExpr0, colors = dynamicColors)
MEs = MEList$eigengenes
MEDiss = 1 - cor(MEs)
METree = hclust(as.dist(MEDiss), method = "average")
pdf(file = "06.Clustering_module.pdf", width = 7, height = 6)
plot(METree, main = "Clustering of module eigengenes", xlab = "", sub = "")
dev.off()

# TOM heatmap for selected genes
moduleColors = dynamicColors
nGenes = ncol(datExpr0)
nSamples = nrow(datExpr0)
select = sample(nGenes, size = 1000)
selectTOM = dissTOM[select, select]
selectTree = hclust(as.dist(selectTOM), method = "average")
selectColors = moduleColors[select]
plotDiss = selectTOM^softPower
diag(plotDiss) = NA
myheatcol = colorpanel(250, "red", "orange", "lemonchiffon")
pdf(file = "07.TOMplot.pdf", width = 7, height = 7)
TOMplot(plotDiss, selectTree, selectColors, main = "Network heatmap plot, selected genes", col = myheatcol)
dev.off()

# Module-trait relationship heatmap
moduleTraitCor = cor(MEs, datTraits, use = "p")
moduleTraitPvalue = corPvalueStudent(moduleTraitCor, nSamples)
pdf(file = "08.Module_trait.pdf", width = 6.5, height = 5.5)
textMatrix = paste(signif(moduleTraitCor, 2), "\n(",
                   signif(moduleTraitPvalue, 1), ")", sep = "")
dim(textMatrix) = dim(moduleTraitCor)
par(mar = c(3.5, 8, 3, 3))
labeledHeatmap(Matrix = moduleTraitCor,
               xLabels = names(datTraits),
               yLabels = names(MEs),
               ySymbols = names(MEs),
               colorLabels = FALSE,
               colors = blueWhiteRed(50),
               textMatrix = textMatrix,
               setStdMargins = FALSE,
               cex.text = 0.7,
               zlim = c(-1,1),
               main = "Module-trait relationships")
dev.off()

# Compute Module Membership (MM) and Gene Significance (GS)
modNames = substring(names(MEs), 3)
geneModuleMembership = as.data.frame(cor(datExpr0, MEs, use = "p"))
MMPvalue = as.data.frame(corPvalueStudent(as.matrix(geneModuleMembership), nSamples))
names(geneModuleMembership) = paste("MM", modNames, sep = "")
names(MMPvalue) = paste("p.MM", modNames, sep = "")
traitNames = names(datTraits)
geneTraitSignificance = as.data.frame(cor(datExpr0, datTraits, use = "p"))
GSPvalue = as.data.frame(corPvalueStudent(as.matrix(geneTraitSignificance), nSamples))
names(geneTraitSignificance) = paste("GS.", traitNames, sep = "")
names(GSPvalue) = paste("p.GS.", traitNames, sep = "")

# Plot Module Membership vs Gene Significance for each module
trait = "Treat"
traitColumn = match(trait, traitNames)  
for (module in modNames) {
  column = match(module, modNames)
  moduleGenes = moduleColors == module
  if (nrow(geneModuleMembership[moduleGenes, ]) > 1) {
    outPdf = paste("09.", trait, "_", module, ".pdf", sep = "")
    pdf(file = outPdf, width = 7, height = 7)
    verboseScatterplot(abs(geneModuleMembership[moduleGenes, column]),
                       abs(geneTraitSignificance[moduleGenes, traitColumn]),
                       xlab = paste("Module Membership in", module, "module"),
                       ylab = paste("Gene significance for", trait),
                       main = "Module membership vs. gene significance",
                       cex
                       