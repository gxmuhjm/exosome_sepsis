#install.packages('e1071')

#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("preprocessCore")

inputFile = "normalize.txt"      # Input normalized expression file
setwd("D:\\bioinfor\\sepsis\\sepsis_exosome\\11.CIBERSORT")  # Set working directory
source("geoCRG11.CIBERSORT.R")   # Source the CIBERSORT R script

# Perform CIBERSORT analysis with 1000 permutations and quantile normalization
outTab = CIBERSORT("ref.txt", inputFile, perm = 1000, QN = TRUE)

# Filter samples with P-value < 0.05 and remove summary columns
outTab = outTab[outTab[, "P-value"] < 0.05, ]
outTab = as.matrix(outTab[, 1:(ncol(outTab) - 3)])

# Add sample IDs as header and output results
outTab = rbind(id = colnames(outTab), outTab)
write.table(outTab, file = "CIBERSORT-Results.txt", sep = "\t", quote = FALSE, col.names = FALSE)
