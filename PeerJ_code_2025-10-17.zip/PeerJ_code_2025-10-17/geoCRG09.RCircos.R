#install.packages("RCircos")

library("RCircos")       # Load the RCircos package
setwd("D:\\bioinfor\\sepsis\\sepsis_exosome\\09.Rcircos")      # Set working directory

# Load cytoband ideogram data
cytoBandIdeogram = read.table("refer.txt", header = TRUE, sep = "\t", check.names = FALSE)
chr.exclude <- NULL
cyto.info <- cytoBandIdeogram
tracks.inside <- 4
tracks.outside <- 0
RCircos.Set.Core.Components(cyto.info, chr.exclude, tracks.inside, tracks.outside)

# Set parameters for the circos plot
rcircos.params <- RCircos.Get.Plot.Parameters()
rcircos.params$text.size = 0.7
rcircos.params$point.size = 5
RCircos.Reset.Plot.Parameters(rcircos.params)

# Generate circos plot
pdf(file = "RCircos.pdf", width = 9, height = 9)
RCircos.Set.Plot.Area()
RCircos.Chromosome.Ideogram.Plot()

# Load gene annotation file and visualize gene labels
RCircos.Gene.Label.Data = read.table("Rcircos.geneLabel.txt", header = TRUE, sep = "\t", check.names = FALSE)
name.col <- 4
side <- "in"

# Draw connectors linking gene names to their chromosomal locations
track.num <- 1
RCircos.Gene.Connector.Plot(RCircos.Gene.Label.Data, track.num, side)

# Plot gene names on the circos ideogram
track.num <- 2
RCircos.Gene.Name.Plot(RCircos.Gene.Label.Data, name.col, track.num, side)
dev.off()
