#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")

library(limma)              # Load the required package
expFile="normalize.txt"     # Expression data file
geneFile="gene.txt"         # Gene list file
setwd("F://WHW//Test_AZ_2022.12.31.6th//06.crgExp")     # Set working directory

# Read the input expression matrix and preprocess the data
rt = read.table(expFile, header = TRUE, sep = "\t", check.names = FALSE)
rt = as.matrix(rt)
rownames(rt) = rt[,1]
exp = rt[,2:ncol(rt)]
dimnames = list(rownames(exp), colnames(exp))
data = matrix(as.numeric(as.matrix(exp)), nrow = nrow(exp), dimnames = dimnames)
data = avereps(data)        # Average expression values for duplicated genes

# Read the gene list file and extract the expression data of cuproptosis-related genes
gene = read.table(geneFile, header = FALSE, sep = "\t", check.names = FALSE)
sameGene = intersect(as.vector(gene[,1]), rownames(data))
geneExp = data[sameGene,]

# Output the expression matrix of cuproptosis-related genes
out = rbind(ID = colnames(geneExp), geneExp)
write.table(out, file = "crgGeneExp.txt", sep = "\t", quote = FALSE, col.names = FALSE)
