#install.packages("reshape2")
#install.packages("ggpubr")

# Load required R packages
library(reshape2)
library(ggpubr)

inputFile = "CIBERSORT-Results.txt"     # Immune cell infiltration result file
setwd("D:\\bioinfor\\sepsis\\sepsis_exosome\\12.barplot")     # Set working directory

# Read immune cell infiltration data
rt = read.table(inputFile, header = TRUE, sep = "\t", check.names = FALSE, row.names = 1)

# Extract control and treatment group samples
con = grepl("_Control", rownames(rt), ignore.case = TRUE)
treat = grepl("_Treat", rownames(rt), ignore.case = TRUE)
conData = rt[con, ]
treatData = rt[treat, ]
conNum = nrow(conData)
treatNum = nrow(treatData)

# Combine data for visualization
data = t(rbind(conData, treatData))

# Define color palette for the barplot
col = c(
  "#7499DD", "#D16571", "#EFC4D6", "#FFDFE5", "#FFD6A5", "#FFF3C1", "#ACEFD1", "#98E2C6", "#C5F4FA",
  "#5C85CC", "#B94E5A", "#D9B3BF", "#FFCCD6", "#FFCC99", "#FFE699", "#94E0BF", "#7FCDB6", "#A6ECF5",
  "#3D5F99", "#80333E", "#B38699", "#E699AC"
)

# Visualize immune cell fractions as a stacked barplot
pdf(file = "barplot.pdf", width = 14.5, height = 8.5)
par(las = 1, mar = c(8, 5, 4, 16), mgp = c(3, 0.1, 0), cex.axis = 1.5)
a1 = barplot(data, col = col, xaxt = "n", yaxt = "n", ylab = "Relative Percent", cex.lab = 1.8)
a2 = axis(2, tick = FALSE, labels = FALSE)
axis(2, a2, paste0(a2 * 100, "%"))
par(srt = 0, xpd = TRUE)

# Add group labels below barplot
rect(xleft = a1[1] - 0.5, ybottom = -0.01, xright = a1[conNum] + 0.5, ytop = -0.06, col = "green")
text(a1[conNum] / 2, -0.035, "Control", cex = 1.8)
rect(xleft = a1[conNum] + 0.5, ybottom = -0.01, xright = a1[length(a1)] + 0.5, ytop = -0.06, col = "red")
text((a1[length(a1)] + a1[conNum]) / 2, -0.035, "Treat", cex = 1.8)

# Add legend for immune cell types
ytick2 = cumsum(data[, ncol(data)])
ytick1 = c(0, ytick2[-length(ytick2)])
legend(par('usr')[2] * 0.98, par('usr')[4], legend = rownames(data), col = col, pch = 15, bty = "n", cex = 1.2)
dev.off()

################## Differential comparison ##################
# Prepare data for ggplot2
Type = gsub("(.*)\\_(.*)", "\\2", rownames(rt))
data = cbind(as.data.frame(t(data)), Type)
data = melt(data, id.vars = c("Type"))
colnames(data) = c("Type", "Immune", "Expression")

# Define color palette for groups
group = levels(factor(data$Type))
bioCol = c("#7499DD", "#D16571", "#EFC4D6", "#FFDFE5", "#FFD6A5", "#FFF3C1", "#ACEFD1", "#98E2C6", "#C5F4FA")
bioCol = bioCol[1:length(group)]

# Generate boxplots comparing immune cell fractions between groups
boxplot = ggboxplot(data, x = "Immune", y = "Expression", color = "Type",
                    xlab = "",
                    ylab = "Fraction",
                    legend.title = "Type",
                    add = "point",
                    width = 0.8,
                    palette = bioCol) +
  rotate_x_text(50) +
  stat_compare_means(aes(group = Type),
                     symnum.args = list(cutpoints = c(0, 0.001, 0.01, 0.05, 1),
                                        symbols = c("***", "**", "*", "")),
                     label = "p.signif")

# Save boxplot as PDF
pdf(file = "immune.diff.pdf", width = 8, height = 6)
print(boxplot)
dev.off()
