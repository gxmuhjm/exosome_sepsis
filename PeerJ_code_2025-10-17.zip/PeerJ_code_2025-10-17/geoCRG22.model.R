#install.packages("caret")
#install.packages("DALEX")
#install.packages("ggplot2")
#install.packages("randomForest")
#install.packages("kernlab")
#install.packages("pROC")
#install.packages("xgboost")

# Load required libraries
library(caret)
library(DALEX)
library(ggplot2)
library(randomForest)
library(kernlab)
library(xgboost)
library(pROC)

set.seed(123)      # Set random seed for reproducibility

inputFile = "normalize.txt"      # File containing normalized expression data
geneFile = "interGenes.txt"      # File containing list of intersecting genes
setwd("D:\\bioinfor\\sepsis\\sepsis_exosome\\22.model\\GSE66099")  # Set working directory

# Read expression data
data = read.table(inputFile, header = TRUE, sep = "\t", check.names = FALSE, row.names = 1)

# Read intersecting gene list and subset expression data
geneRT = read.table(geneFile, header = FALSE, sep = "\t", check.names = FALSE)
data = data[as.vector(geneRT[,1]), ]
row.names(data) = gsub("-", "_", row.names(data))  # Replace '-' with '_'

# Prepare phenotype information
data = t(data)
group = gsub("(.*)\\_(.*)", "\\2", row.names(data))  # Extract group labels
data = as.data.frame(data)
data$Type = group

# Split dataset into training (70%) and testing (30%) sets
inTrain <- createDataPartition(y = data$Type, p = 0.7, list = FALSE)
train <- data[inTrain, ]
test <- data[-inTrain, ]

# Define cross-validation method
control = trainControl(method = "repeatedcv", number = 5, savePredictions = TRUE)

# Train Random Forest model
mod_rf = train(Type ~ ., data = train, method = 'rf', trControl = control)

# Train SVM model with radial basis kernel
mod_svm = train(Type ~ ., data = train, method = "svmRadial", prob.model = TRUE, trControl = control)

# Train XGBoost model
mod_xgb = train(Type ~ ., data = train, method = "xgbDART", trControl = control)

# Train GLM (logistic regression) model
mod_glm = train(Type ~ ., data = train, method = "glm", family = "binomial", trControl = control)

# Define prediction function for DALEX
p_fun = function(object, newdata){
  predict(object, newdata = newdata, type = "prob")[,2]
}

# Prepare testing labels
yTest = ifelse(test$Type == "Control", 0, 1)

# Explain and evaluate model performance using DALEX
explainer_rf = explain(mod_rf, label = "RF", data = test, y = yTest, predict_function = p_fun, verbose = FALSE)
mp_rf = model_performance(explainer_rf)

explainer_svm = explain(mod_svm, label = "SVM", data = test, y = yTest, predict_function = p_fun, verbose = FALSE)
mp_svm = model_performance(explainer_svm)

explainer_xgb = explain(mod_xgb, label = "XGB", data = test, y = yTest, predict_function = p_fun, verbose = FALSE)
mp_xgb = model_performance(explainer_xgb)

explainer_glm = explain(mod_glm, label = "GLM", data = test, y = yTest, predict_function = p_fun, verbose = FALSE)
mp_glm = model_performance(explainer_glm)

# Plot residuals of all models
pdf(file = "residual.pdf", width = 6, height = 6)
p1 <- plot(mp_rf, mp_svm, mp_xgb, mp_glm)
print(p1)
dev.off()

# Plot boxplots of residuals
pdf(file = "boxplot.pdf", width = 6, height = 6)
p2 <- plot(mp_rf, mp_svm, mp_xgb, mp_glm, geom = "boxplot")
print(p2)
dev.off()

# Generate ROC curves
pred1 = predict(mod_rf, newdata = test, type = "prob")
pred2 = predict(mod_svm, newdata = test, type = "prob")
pred3 = predict(mod_xgb, newdata = test, type = "prob")
pred4 = predict(mod_glm, newdata = test, type = "prob")

roc1 = roc(yTest, as.numeric(pred1[,2]))
roc2 = roc(yTest, as.numeric(pred2[,2]))
roc3 = roc(yTest, as.numeric(pred3[,2]))
roc4 = roc(yTest, as.numeric(pred4[,2]))

pdf(file = "ROC.pdf", width = 5, height = 5)
plot(roc1, print.auc = FALSE, legacy.axes = TRUE, main = "", col = "red")
plot(roc2, print.auc = FALSE, legacy.axes = TRUE, main = "", col = "blue", add = TRUE)
plot(roc3, print.auc = FALSE, legacy.axes = TRUE, main = "", col = "green", add = TRUE)
plot(roc4, print.auc = FALSE, legacy.axes = TRUE, main = "", col = "yellow", add = TRUE)
legend('bottomright',
       c(paste0('RF: ', sprintf("%.03f", roc1$auc)),
         paste0('SVM: ', sprintf("%.03f", roc2$auc)),
         paste0('XGB: ', sprintf("%.03f", roc3$auc)),
         paste0('GLM: ', sprintf("%.03f", roc4$auc))),
       col = c("red", "blue", "green", "yellow"), lwd = 2, bty = 'n')
dev.off()

# Calculate variable importance for each model
importance_rf = variable_importance(explainer_rf, loss_function = loss_root_mean_square)
importance_svm = variable_importance(explainer_svm, loss_function = loss_root_mean_square)
importance_xgb = variable_importance(explainer_xgb, loss_function = loss_root_mean_square)
importance_glm = variable_importance(explainer_glm, loss_function = loss_root_mean_square)

# Plot variable importance
pdf(file = "importance.pdf", width = 7, height = 10)
plot(importance_rf[c(1, (ncol(data)-8):(ncol(data)+1)), ],
     importance_svm[c(1, (ncol(data)-8):(ncol(data)+1)), ],
     importance_xgb[c(1, (ncol(data)-8):(ncol(data)+1)), ],
     importance_glm[c(1, (ncol(data)-8):(ncol(data)+1)), ])
dev.off()

# Save top important genes for each model
geneNum = 5     # Number of top genes to extract
write.table(importance_rf[(ncol(data)-geneNum+2):(ncol(data)+1), ], file = "importanceGene.RF.txt", sep = "\t", quote = FALSE, row.names = FALSE)
write.table(importance_svm[(ncol(data)-geneNum+2):(ncol(data)+1), ], file = "importanceGene.SVM.txt", sep = "\t", quote = FALSE, row.names = FALSE)
write.table(importance_xgb[(ncol(data)-geneNum+2):(ncol(data)+1), ], file = "importanceGene.XGB.txt", sep = "\t", quote = FALSE, row.names = FALSE)
write.table(importance_glm[(ncol(data)-geneNum+2):(ncol(data)+1), ], file = "importanceGene.GLM.txt", sep = "\t", quote = FALSE, row.names = FALSE)