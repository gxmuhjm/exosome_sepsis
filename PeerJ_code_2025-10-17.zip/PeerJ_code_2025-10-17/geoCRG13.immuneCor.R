#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")

#install.packages("tidyverse")
#install.packages("ggplot2")
#install.packages("reshape2")

# Load required R packages
library(limma)
library(reshape2)
library(tidyverse)
library(ggplot2)

expFile = "diffGeneExp.txt"           # Differential gene expression file
immFile = "CIBERSORT-Results.txt"    # Immune cell infiltration result file
setwd("D:\\bioinfor\\sepsis\\sepsis_exosome\\13.immuneCor")  # Set working directory

# Read gene expression file and preprocess
rt = read.table(expFile, header = TRUE, sep = "\t", check.names = FALSE)
rt = as.matrix(rt)
rownames(rt) = rt[,1]
exp = rt[,2:ncol(rt)]
dimnames = list(rownames(exp), colnames(exp))
data = matrix(as.numeric(as.matrix(exp)), nrow = nrow(exp), dimnames = dimnames)
data = avereps(data)   # Average duplicated gene expression values

# Filter to keep only treatment group samples
group = gsub("(.*)\\_(.*)", "\\2", colnames(data))
data = data[, group == "Treat", drop = FALSE]
data = t(data)

# Read immune cell infiltration data and match samples
immune = read.table(immFile, header = TRUE, sep = "\t", check.names = FALSE, row.names = 1)
sameSample = intersect(row.names(data), row.names(immune))
data = data[sameSample, , drop = FALSE]
immune = immune[sameSample, , drop = FALSE]

# Perform Spearman correlation analysis between gene expression and immune cell fractions
outTab = data.frame()
for(cell in colnames(immune)){
  if(sd(immune[, cell]) == 0){ next }  # Skip immune cells with zero variance
  for(gene in colnames(data)){
    x = as.numeric(immune[, cell])
    y = as.numeric(data[, gene])
    corT = cor.test(x, y, method = "spearman")
    cor = corT$estimate
    pvalue = corT$p.value
    text = ifelse(pvalue < 0.001, "***",
                  ifelse(pvalue < 0.01, "**",
                         ifelse(pvalue < 0.05, "*", "")))
    outTab = rbind(outTab, cbind(Gene = gene, Immune = cell, cor, text, pvalue))
  }
}

# Generate heatmap of correlations
outTab$cor = as.numeric(outTab$cor)
pdf(file = "cor.pdf", width = 8, height = 8)
ggplot(outTab, aes(Immune, Gene)) + 
  geom_tile(aes(fill = cor), colour = "grey", size = 1) +
  scale_fill_gradient2(low = "#006258", mid = "white", high = "#FD4243") + 
  geom_text(aes(label = text), col = "black", size = 3) +
  theme_minimal() +   # Remove background
  theme(axis.title.x = element_blank(), 
        axis.ticks.x = element_blank(), 
        axis.title.y = element_blank(),
        axis.text.x = element_text(angle = 45, hjust = 1, size = 8, face = "bold"),  # X-axis text
        axis.text.y = element_text(size = 8, face = "bold")) +  # Y-axis text
  labs(fill = paste0("***  p<0.001","\n", "**  p<0.01","\n", " *  p<0.05","\n", "\n","Correlation")) +  # Legend
  scale_x_discrete(position = "bottom")  # Place X-axis at bottom
dev.off()