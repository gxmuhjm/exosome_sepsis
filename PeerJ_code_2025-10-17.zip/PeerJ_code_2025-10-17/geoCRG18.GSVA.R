#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")

# Load required packages
library(reshape2)
library(ggpubr)
library(limma)
library(GSEABase)
library(GSVA)
library(devtools)
library(IRanges)

expFile = "normalize.txt"              # File containing normalized gene expression
clusterFile = "cluster.txt"            # File containing cluster information
gmtFile = "c2.cp.kegg.symbols.gmt"     # GMT file for KEGG pathways
setwd("D:\\bioinfor\\sepsis\\sepsis_exosome\\18.GSVAδ")  # Set working directory

# Read gene expression file and convert to matrix
rt = read.table(expFile, header = TRUE, sep = "\t", check.names = FALSE)
rt = as.matrix(rt)
rownames(rt) = rt[, 1]
exp = rt[, 2:ncol(rt)]
dimnames = list(rownames(exp), colnames(exp))
data = matrix(as.numeric(as.matrix(exp)), nrow = nrow(exp), dimnames = dimnames)
data = avereps(data)   # Average replicate gene expression

# Filter to retain only treatment samples
group = gsub("(.*)\\_(.*)", "\\2", colnames(data))
data = data[, group == "Treat", drop = FALSE]

# Read GMT pathway file
geneSets = getGmt(gmtFile, geneIdType = SymbolIdentifier())

# Perform GSVA (Gene Set Variation Analysis)
ssgseaScore = gsva(data, geneSets, method = 'gsva')

# Normalize GSVA scores to 0-1 range
normalize = function(x){
  return((x - min(x)) / (max(x) - min(x)))
}
ssgseaScore = normalize(ssgseaScore)

# Read cluster information
cluster = read.table(clusterFile, header = TRUE, sep = "\t", check.names = FALSE, row.names = 1)
nameC1 = row.names(cluster[cluster$Cluster == "C1", , drop = FALSE])
nameC2 = row.names(cluster[cluster$Cluster == "C2", , drop = FALSE])
dataC1 = ssgseaScore[, nameC1, drop = FALSE]
dataC2 = ssgseaScore[, nameC2, drop = FALSE]
conNum = ncol(dataC1)
treatNum = ncol(dataC2)
data = cbind(dataC1, dataC2)
Type = c(rep("C1", conNum), rep("C2", treatNum))

# Differential analysis of pathways using t-test
outTab = data.frame()
for (i in row.names(data)) {
  test = t.test(data[i, ] ~ Type)
  pvalue = test$p.value
  t = test$statistic
  if (pvalue < 0.05) {
    Sig = ifelse(pvalue > 0.05, "Not", ifelse(t > 0, "Up", "Down"))
    outTab = rbind(outTab, cbind(Pathway = i, t, pvalue, Sig))
  }
}

# Alternatively, read pre-saved CSV of differential pathways
outTab <- read.csv("pathway1.csv", header = TRUE)

# Inspect the differential pathway table
print(outTab)

# Plot top significant pathways
termNum = 9      # Number of top pathways to display
outTab = outTab[order(outTab$t), ]
outTab = outTab[c(1:termNum, (nrow(outTab) - termNum):nrow(outTab)), ]  # Select top and bottom pathways
pdf(file = "barplot_KEGG.pdf", width = 14, height = 14)
outTab$t = as.numeric(outTab$t)
outTab$Sig = factor(outTab$Sig, levels = c("Down", "Up"))
gg1 = ggbarplot(outTab, x = "Pathway", y = "t", fill = "Sig", color = "white",
                palette = c("#BA6DEC", "#6BD9F5"), sort.val = "asc", sort.by.groups = TRUE,
                rotate = TRUE, legend = "right", title = "",
                xlab = "Term", ylab = "t value of GSVA score, C2 vs C1",
                legend.title = "Group", x.text.angle = 60)
print(gg1)
dev.off()
