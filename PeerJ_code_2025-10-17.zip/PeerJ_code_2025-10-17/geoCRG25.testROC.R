#install.packages("caret")
#install.packages("DALEX")
#install.packages("ggplot2")
#install.packages("randomForest")
#install.packages("kernlab")
#install.packages("pROC")
#install.packages("xgboost")

# Load required libraries
library(caret)        # For model training and cross-validation
library(DALEX)        # For model explainability (optional)
library(ggplot2)      # For plotting
library(randomForest) # For Random Forest model
library(kernlab)      # For SVM model
library(xgboost)      # For XGBoost model
library(pROC)         # For ROC curve and AUC calculation

set.seed(123)  # Set random seed for reproducibility

inputFile = "GSE132903_normalize.txt"   # File containing normalized expression data
geneFile = "importanceGene.SVM.txt"     # File containing top important genes
setwd("F://WHW//Test_AZ_2022.12.31.6th//25.testROC_GSE132903")  # Set working directory

# Read expression data
data = read.table(inputFile, header = TRUE, sep = "\t", check.names = FALSE, row.names = 1)
row.names(data) = gsub("-", "_", row.names(data))  # Replace '-' with '_' for compatibility

# Read top gene list and subset expression data
geneRT = read.table(geneFile, header = TRUE, sep = "\t", check.names = FALSE)
data = data[as.vector(geneRT[,1]), ]

# Prepare phenotype information
data = t(data)
group = gsub("(.*)\\_(.*)", "\\2", row.names(data))  # Extract group labels from sample names
data = as.data.frame(data)
data$Type = group

# Split data into training and test sets (70% training, 30% testing)
inTrain <- createDataPartition(y = data$Type, p = 0.7, list = FALSE)
train <- data[inTrain, ]
test <- data[-inTrain, ]

# Train model based on selected gene file
control = trainControl(method = "repeatedcv", number = 5, savePredictions = TRUE)

if (geneFile == "importanceGene.RF.txt") {
  # Random Forest model
  model = train(Type ~ ., data = train, method = 'rf', trControl = control)
} else if (geneFile == "importanceGene.SVM.txt") {
  # Support Vector Machine model with radial kernel
  model = train(Type ~ ., data = train, method = "svmRadial", prob.model = TRUE, trControl = control)
} else if (geneFile == "importanceGene.XGB.txt") {
  # XGBoost model
  model = train(Type ~ ., data = train, method = "xgbDART", trControl = control)
} else if (geneFile == "importanceGene.GLM.txt") {
  # Generalized Linear Model (logistic regression)
  model = train(Type ~ ., data = train, method = "glm", family = "binomial", trControl = control)
}

# ROC analysis
yTest = ifelse(test$Type == "Control", 0, 1)  # Convert labels to numeric (0 = Control, 1 = Disease)
pred1 = predict(model, newdata = test, type = "prob")
roc1 = roc(yTest, as.numeric(pred1[,2]))  # Compute ROC curve
ci1 = ci.auc(roc1, method = "bootstrap")  # Compute 95% confidence interval
ciVec = as.numeric(ci1)

# Plot ROC curve with 95% CI
pdf(file = "ROC.pdf", width = 5, height = 5)
plot(roc1, print.auc = TRUE, legacy.axes = TRUE, main = "", col = "red")
text(0.39, 0.43, paste0("95% CI: ", sprintf("%.03f", ciVec[1]), "-", sprintf("%.03f", ciVec[3])), col = "red")
dev.off()