###### Video source: https://ke.biowolf.cn
###### BioWolf learning: https://www.biowolf.cn/
###### WeChat public account: biowolf_cn
###### Email: biowolf@foxmail.com
###### WeChat contact: 18520221056

# Install required packages if needed
#install.packages("colorspace")
#install.packages("stringi")
#install.packages("ggplot2")

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("org.Hs.eg.db")
#BiocManager::install("DOSE")
BiocManager::install("clusterProfiler")
BiocManager::install("enrichplot")

# Load required libraries
library("clusterProfiler")  # KEGG/GO enrichment analysis
library("org.Hs.eg.db")     # Human gene annotation
library("enrichplot")       # Visualization of enrichment results
library("ggplot2")          # For plotting

# Set significance thresholds
pvalueFilter = 0.05       # p-value cutoff
adjPvalFilter = 0.05      # adjusted p-value cutoff (FDR)

# Select color for plots based on significance
colorSel = "p.adjust"
if (adjPvalFilter > 0.05) {
  colorSel = "pvalue"
}

# Set working directory
setwd("D:\\bioinfor\\sepsis\\sepsis_exosome\\21.3 KEGGδ")

# Read gene list file
rt = read.table("intergenes.diff.txt", header = TRUE, sep = "\t", check.names = FALSE)

# Map gene symbols to Entrez IDs
genes = unique(as.vector(rt[,1]))
entrezIDs = mget(genes, org.Hs.egSYMBOL2EG, ifnotfound = NA)
entrezIDs = as.character(entrezIDs)
rt = cbind(rt, entrezIDs)
rt = rt[rt[,"entrezIDs"] != "NA", ]  # Remove genes without Entrez ID
gene = rt$entrezID
geneFC = rt$logFC
names(geneFC) = gene

# KEGG enrichment analysis
install.packages('R.utils')
R.utils::setOption("clusterProfiler.download.method",'auto')
kk <- enrichKEGG(gene = gene, organism = "hsa", pvalueCutoff = 1, qvalueCutoff = 1)

# Convert enrichment results to data frame
KEGG = as.data.frame(kk)

# Map Entrez IDs back to gene symbols for display
KEGG$geneID = as.character(sapply(KEGG$geneID, function(x) 
  paste(rt$genes[match(strsplit(x, "/")[[1]], as.character(rt$entrezID))], collapse = "/")
))

# Filter results based on significance
KEGG = KEGG[(KEGG$pvalue < pvalueFilter & KEGG$p.adjust < adjPvalFilter), ]

# Save filtered KEGG enrichment results
write.table(KEGG, file = "KEGG.txt", sep = "\t", quote = FALSE, row.names = FALSE)

# Determine number of terms to display
showNum = 30
if (nrow(KEGG) < showNum) {
  showNum = nrow(KEGG)
}

# Bar plot of top KEGG pathways
pdf(file = "barplot.pdf", width = 8, height = 7)
barplot(kk, drop = TRUE, showCategory = showNum, label_format = 100, color = colorSel)
dev.off()

# Bubble plot of top KEGG pathways
pdf(file = "bubble.pdf", width = 6.5, height = 7)
dotplot(kk, showCategory = showNum, orderBy = "GeneRatio", label_format = 100, color = colorSel)
dev.off()

# Enrichment network plot (circular)
pdf(file = "cnetplot.pdf", width = 9, height = 5.25)
kkx = setReadable(kk, 'org.Hs.eg.db', 'ENTREZID')  # Convert IDs to gene symbols for plot
cnet = cnetplot(kkx, circular = TRUE, foldChange = geneFC, showCategory = 5, colorEdge = TRUE)
print(cnet)
dev.off()

###### Video source: https://ke.biowolf.cn
###### BioWolf learning: https://www.biowolf.cn/
###### WeChat public account: biowolf_cn
###### Email: biowolf@foxmail.com
###### WeChat contact: 18520221056
