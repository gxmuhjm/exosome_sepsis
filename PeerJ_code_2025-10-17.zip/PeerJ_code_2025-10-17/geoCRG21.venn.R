#install.packages("VennDiagram")

library(VennDiagram)       # Load the VennDiagram package

diseaseFile = "hubGenes_MMturquoise.txt"      # File containing hub genes from disease WGCNA
clusterFile = "cluster.hubGenes_MMturquoise.txt"  # File containing hub genes from cluster WGCNA
setwd("F://WHW//Test_AZ_2022.12.31.6th//21.venn")  # Set working directory

geneList = list()  # Initialize a list to store gene sets

# Read disease WGCNA hub gene file
rt = read.table(diseaseFile, header = FALSE, sep = "\t", check.names = FALSE)
geneNames = as.vector(rt[,1])             # Extract gene names
geneNames = gsub("^ | $", "", geneNames)  # Remove leading and trailing whitespace
uniqGene = unique(geneNames)              # Keep unique gene names
geneList[["Disease WGCNA"]] = uniqGene    # Add to gene list

# Read cluster WGCNA hub gene file
rt = read.table(clusterFile, header = FALSE, sep = "\t", check.names = FALSE)
geneNames = as.vector(rt[,1])             # Extract gene names
geneNames = gsub("^ | $", "", geneNames)  # Remove leading and trailing whitespace
uniqGene = unique(geneNames)              # Keep unique gene names
geneList[["Cluster WGCNA"]] = uniqGene    # Add to gene list

# Create Venn diagram
venn.plot = venn.diagram(geneList,
                         filename = NULL,
                         fill = c("cornflowerblue", "darkorchid1"),
                         scaled = FALSE,
                         cat.pos = c(-1, 1),
                         cat.col = c("cornflowerblue", "darkorchid1"),
                         cat.cex = 1)

# Save Venn diagram as PDF
pdf(file = "venn.pdf", width = 5, height = 5)
grid.draw(venn.plot)
dev.off()

# Identify intersecting genes between the two gene sets
interGenes = Reduce(intersect, geneList)
write.table(file = "interGenes.txt", interGenes, sep = "\t", quote = FALSE, col.names = FALSE, row.names = FALSE)
