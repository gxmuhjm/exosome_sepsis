#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("ConsensusClusterPlus")

library(ConsensusClusterPlus)      # Load ConsensusClusterPlus package

expFile = "diffGeneExp.txt"        # Differential gene expression file
workDir = "F://WHW//Test_AZ_2022.12.31.6th//14.cluster"  # Set working directory
setwd(workDir)                      # Change working directory

# Read the gene expression file
data = read.table(expFile, header = TRUE, sep = "\t", check.names = FALSE, row.names = 1)
data = as.matrix(data)

# Filter to keep only treatment group samples
group = sapply(strsplit(colnames(data), "\\_"), "[", 2)
data = data[, group == "Treat"]

# Perform consensus clustering
maxK = 9  # Maximum number of clusters to test
results = ConsensusClusterPlus(data,
                               maxK = maxK,          # Maximum K to evaluate
                               reps = 50,            # Number of resampling iterations
                               pItem = 0.8,          # Proportion of items to sample in each iteration
                               pFeature = 1,         # Proportion of features to sample in each iteration
                               title = workDir,      # Output directory for results and plots
                               clusterAlg = "km",    # Clustering algorithm: k-means
                               distance = "euclidean",  # Distance metric: Euclidean
                               seed = 123456,        # Random seed for reproducibility
                               plot = "png")         # Save plots as PNG

# Calculate the item-consensus (ICL) for each K
calcICL(results, title = "consensusScore", plot = "png")

# Determine the final cluster assignments
clusterNum = 2        # Selected cluster number based on consensus results
cluster = results[[clusterNum]][["consensusClass"]]
cluster = as.data.frame(cluster)
colnames(cluster) = c("Cluster")
cluster$Cluster = paste0("C", cluster$Cluster)
outTab = cbind(t(data), cluster)
outTab = rbind(ID = colnames(outTab), outTab)
write.table(outTab, file = "cluster.txt", sep = "\t", quote = FALSE, col.names = FALSE)

# Reference: https://cloud.tencent.com/developer/article/2019378

# Notes on consensus clustering output:
# - The CDF plot (consensus010.png) shows the cumulative distribution function of consensus values for each K.
#   This helps to visualize cluster stability and select the optimal K.
# - The delta area plot (consensus011.png) shows the relative change in CDF area between successive K values.
#   The K with the largest relative increase indicates the most stable clustering.
# - Use these plots to select the optimal number of clusters for downstream analyses (clusterNum).