#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")

#install.packages("reshape2")
#install.packages("ggpubr")

# Load required packages
library(limma)
library(reshape2)
library(ggpubr)

clusterFile = "cluster.txt"           # File containing cluster information
immFile = "CIBERSORT-Results.txt"     # File containing immune cell infiltration results
setwd("D:\\bioinfor\\sepsis\\sepsis_exosome\\17.clusterImm")  # Set working directory

# Read immune cell infiltration results
immune = read.table(immFile, header = TRUE, sep = "\t", check.names = FALSE, row.names = 1)

# Filter to retain only treatment samples
group = gsub("(.*)\\_(.*)", "\\2", row.names(immune))
data = immune[group == "Treat", , drop = FALSE]

# Read cluster information
Cluster = read.table(clusterFile, header = TRUE, sep = "\t", check.names = FALSE, row.names = 1)
sameSample = intersect(row.names(data), row.names(Cluster))
rt = cbind(data[sameSample, , drop = FALSE], Cluster[sameSample, "Cluster", drop = FALSE])
rt = rt[order(rt$Cluster, decreasing = FALSE), ]
conNum = nrow(rt[rt$Cluster == "C1", ])
treatNum = nrow(rt[rt$Cluster == "C2", ])

########## Stacked bar plot ##########
data = t(rt[, -ncol(rt)])
pdf(file = "barplot.pdf", width = 14.5, height = 8)

# Define color palette
col <- c(
  "#77bfa7", "#7dbda4", "#83baa1", "#89b89e", "#90b59b", "#96b398", "#9cb195", 
  "#a2ae92", "#a8ac8f", "#aeaa8c", "#b4a789", "#bba585", "#c1a282", "#c7a07f", 
  "#cd9e7c", "#d39b79", "#d99976", "#df9773", "#e69470", "#ec926d", "#f28f6a", 
  "#f88d67"
)

# Plot stacked barplot
par(las = 1, mar = c(8, 5, 4, 16), mgp = c(3, 0.1, 0), cex.axis = 1.5)
a1 = barplot(data, col = col, xaxt = "n", yaxt = "n", ylab = "Relative Percent", cex.lab = 1.8)
a2 = axis(2, tick = FALSE, labels = FALSE)
axis(2, a2, paste0(a2 * 100, "%"))
par(srt = 0, xpd = TRUE)

# Add cluster labels below bars
rect(xleft = a1[1] - 0.5, ybottom = -0.01, xright = a1[conNum] + 0.5, ytop = -0.06, col = "green")
text(a1[conNum]/2, -0.035, "C1", cex = 2)
rect(xleft = a1[conNum] + 0.5, ybottom = -0.01, xright = a1[length(a1)] + 0.5, ytop = -0.06, col = "red")
text((a1[length(a1)] + a1[conNum])/2, -0.035, "C2", cex = 2)

# Add legend
ytick2 = cumsum(data[, ncol(data)])
ytick1 = c(0, ytick2[-length(ytick2)])
legend(par('usr')[2]*0.98, par('usr')[4], legend = rownames(data), col = col, pch = 15, bty = "n", cex = 1.3)
dev.off()

################## Boxplot ##################
# Convert data to ggplot2 format
data = rt
data = melt(data, id.vars = c("Cluster"))
colnames(data) = c("Cluster", "Immune", "Expression")

# Generate boxplot
group = levels(factor(data$Cluster))
bioCol = c("#77BFA7","#F88D67")  # Color for clusters
bioCol = bioCol[1:length(group)]
boxplot = ggboxplot(data, x = "Immune", y = "Expression", color = "Cluster",
                    xlab = "",
                    ylab = "Fraction",
                    legend.title = "Cluster",
                    add = "point",
                    width = 0.8,
                    palette = bioCol) +
  rotate_x_text(45) +
  stat_compare_means(aes(group = Cluster),
                     symnum.args = list(cutpoints = c(0, 0.001, 0.01, 0.05, 1), symbols = c("***", "**", "*", "")),
                     label = "p.signif")

# Save boxplot
pdf(file = "immune1.diff.pdf", width = 18, height = 11)
print(boxplot)
dev.off()
